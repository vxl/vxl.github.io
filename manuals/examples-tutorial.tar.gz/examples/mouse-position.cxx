// mouse-position.cc
//
// This example displays the mouse position when the left mouse button is pressed.

#include <vgui/vgui.h>
#include <vgui/vgui_image_tableau.h>
#include <vgui/vgui_viewer2D.h>

struct my_tableau : public vgui_image_tableau 
{
  my_tableau(char const *f) : vgui_image_tableau(f){ }
  ~my_tableau() { }
  
  bool handle(const vgui_event &e) 
    {
    if (e.type == vgui_BUTTON_DOWN && e.button == vgui_LEFT && e.modifier == 0)
    {
      cout << "selecting at " << e.wx << " " << e.wy << endl;
      return true; // event has been used 
    }
 
    // We are not interested in other events, so pass event to base class:
    return vgui_image_tableau::handle(e);  
  }
};

int main(int argc,char **argv) 
{
  vgui::init(argc, argv);
  
  // Load an image into our tableau:
  vgui_tableau_ref my_tab = new my_tableau("/users/kym/target/target/vgui/kym_examples/images/basement00.tif");
 
  // Put the tableau inside a 2D viewer tableau:
  vgui_viewer2D_new viewer(my_tab);
 
  // Start event loop, using easy method.
  return vgui::run(viewer, 512, 512);
}
