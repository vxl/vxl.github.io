// mouse-draw-line.cxx
//
// This example a line is drawn by clicking on the end points.

#include <vgui/vgui.h>
#include <vgui/vgui_tableau.h>
#include <vgui/vgui_drag_mixin.h>
#include <vgui/vgui_projection_inspector.h>
#include <vgui/vgui_image_tableau.h>
#include <vgui/vgui_viewer2D.h>
#include <vgui/vgui_easy2D.h>

struct my_tableau : public vgui_easy2D
{
  float start_x;
  float start_y;
  
  my_tableau(vgui_image_tableau_ref imtab) :
    vgui_easy2D(imtab)
    {
      start_x = -1;
      start_y = -1;
    }
  ~my_tableau() { }

  bool handle(const vgui_event &e) 
  {
    if (e.type == vgui_BUTTON_DOWN && e.button == vgui_LEFT && e.modifier == 0)
    {
      // Convert the coordinates from viewport coords to image coords:
      vgui_projection_inspector pi;
      float ix, iy;
      pi.window_to_image_coordinates(int(e.wx),int(e.wy), ix,iy);

      if (start_x == -1)
      {
        start_x = ix;
        start_y = iy;
      }
      else
      { 
        this->set_line_width(3);
        this->add_line(start_x, start_y, ix, iy);
        start_x = start_y = -1;
      }
      cout << "selecting at " << e.wx << " " << e.wy << endl;
      return true; // event has been used 
    }
 
    // We are not interested in other events, so pass event to base class:
    return vgui_easy2D::handle(e);  
  }
};

struct my_tableau_new : public vgui_easy2D_ref {
  // is this naughty? perhaps it is.
  my_tableau_new(vgui_image_tableau_ref const& i) : vgui_easy2D_ref(new my_tableau(i)) { }
};

int main(int argc,char **argv) 
{
  vgui::init(argc, argv);
 
  // Load an image into an image tableau:
  vgui_image_tableau_new image("/users/kym/target/target/vgui/kym_examples/images/basement00.tif");
 
  // Put the image tableau inside our tableau:
  my_tableau_new my_tab(image);
  
  vgui_viewer2D_new viewer(my_tab);
 
  // Create a window, add the tableau and show it on screen:
  return vgui::run(viewer, 512, 512);
}
