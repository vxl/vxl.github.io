// rubberband.cxx
//
#include <vcl/vcl_cassert.h>
#include <vgui/vgui_image_tableau.h>
#include <vgui/vgui_easy2D.h>
#include <vgui/vgui_viewer2D.h>
#include <vgui/vgui_rubberbander.h>
#include <vgui/vgui_menu.h>
#include <vgui/vgui.h>

static vgui_rubberbander_ref rubber;

static void point(const void *)
{
  cerr << __FILE__ " hello, fsm?" << endl;
  rubber->rubberband_point();
}

static void line(const void*)
{
  rubber->rubberband_line();
}

static void infinite_line(const void*)
{
  rubber->rubberband_infinite_line();
}

static void circle(const void*)
{
  rubber->rubberband_circle();
}

static void polygon(const void*)
{
  rubber->rubberband_polygon();
}
static void linestrip(const void *)
{
  rubber->rubberband_linestrip();
}
// Create a vgui.menu:
vgui_menu create_menus()
{
  vgui_menu objs;
  objs.add("point",point);
  objs.add("line",line);
  objs.add("infinite line", infinite_line);
  objs.add("circle",circle);
  objs.add("polygon", polygon);
  objs.add("linestrip",linestrip);
  vgui_menu bar;
  bar.add("Objects",objs);
 
  return bar;
}

int main(int argc, char **argv) 
{
  vgui::init(argc, argv);

  assert(argv[1]);
  vgui_image_tableau_new image(argv[1]);

  vgui_easy2D_new easy(image);

  rubber = vgui_rubberbander_new(easy);
  
  vgui_viewer2D_new zoom(rubber);
 
  return vgui::run(zoom, image->width(), image->height(), create_menus());
}
