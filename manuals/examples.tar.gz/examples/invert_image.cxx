// Loads the image given by the first command line argument, inverts
// it and saves it to the filename given by the second command line argument.
#include <vcl/vcl_string.h>
#include <vbl/vbl_arg.h>
#include <vil/vil_load.h>
#include <vil/vil_save.h>
#include <vil/vil_memory_image_of.h>
#include <vil/vil_buffer.h>

int main(int argc, char** argv)
{
  vbl_arg<vcl_string> input_filename(0, "input");
  vbl_arg<vcl_string> output_filename(0, "output");
  vbl_arg_parse(argc, argv);

  // Load image:
  vil_image in_image = vil_load(input_filename().c_str());

  // Copy to unsigned char buffer
  vil_memory_image_of<unsigned char> inimg(in_image);

  // Make the inverted image to save, same height and width as original:
  vil_memory_image_of<unsigned char> outimg(in_image.width(), in_image.height());

  // Invert each pixel and write to the new image:
  for (int xcount=0; xcount < in_image.width(); xcount++)
    for (int ycount=0; ycount < in_image.height(); ycount++)
     outimg(xcount, ycount) = 255 - inimg(xcount, ycount);

  // Save image:
  vil_save(outimg, output_filename().c_str());
}
