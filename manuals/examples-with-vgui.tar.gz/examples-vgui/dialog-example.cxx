// dialog-example.cxx
// 
// This example makes a dialog box and attaches it to a menu item.

#include <vbl/vbl_arg.h> 
#include <vbl/vbl_bool_ostream.h> 
#include <vgui/vgui.h> 
#include <vgui/vgui_menu.h> 
#include <vgui/vgui_dialog.h>
#include <vgui/vgui_image_tableau.h> 
#include <vgui/vgui_viewer2D.h> 
#include <vgui/vgui_shell_tableau.h>

// Make a vgui.dialog: 
static void test_dialog(const void*) 
{
  static int int_value = 2; 
  static long long_value = 3; 
  static float float_value = 3.1; 
  static double double_value = 4.2; 
  static vcl_string string_value = "dialog test"; 
  static bool bool_value = true;
  static vcl_string file_value = "/tmp/myfile.txt";
  static vcl_string regexp = "*.txt";
   static vcl_string color_value = "blue";

  static int choice_value = 1; 
  vcl_vector<vcl_string> labels; 
  labels.push_back(vcl_string("fltk"));
  labels.push_back(vcl_string("motif")); 
  labels.push_back(vcl_string("gtk")); 
  labels.push_back(vcl_string("glut")); 
  labels.push_back(vcl_string("glX"));

  vgui_dialog mydialog("My dialog"); 
  mydialog.field("int value", int_value); 
  mydialog.field("long value", long_value); 
  mydialog.field("float value", float_value); 
  mydialog.field("double value", double_value);
  mydialog.field("string value", string_value);
  mydialog.checkbox("bool value", bool_value);
  mydialog.choice("choice value", labels, choice_value);
  mydialog.message("This is a message");
  mydialog.inline_file("file browser", regexp, file_value);
  mydialog.inline_color("color value", color_value);

  if (mydialog.ask())
  { 
    cerr << "int_value : " << int_value << endl; 
    cerr << "long_value : " << long_value << endl; 
    cerr << "float_value : " << float_value << endl; 
    cerr << "double_value : " << double_value << endl; 
    cerr << "string_value : " << string_value << endl; 
    cerr << "bool_value : " << vbl_bool_ostream::true_false(bool_value) << endl; 
    cerr << "choice_value : " << choice_value << " " << labels[choice_value] << endl;
    cerr << "file_value: " << file_value << endl;
    cerr << "color_value: " << color_value << endl;
  }
} 

// Create a vgui.menu with an item which shows the dialog box: 
vgui_menu create_menus()
{ 
  vgui_menu test;
  test.add("Dialog", test_dialog);
  
  vgui_menu bar; 
  bar.add("Test",test);

  return bar;
} 

int main(int argc, char ** argv) 
{
  vgui::init(argc,argv);

  vgui_image_tableau_new image(argv[1] ? argv[1] : "/users/fsm/images/pig.jpg");
  vgui_viewer2D_new viewer(image);

  // Create a window with a menu, add the tableau and show it on screen: 
  return vgui::run(vgui_shell_tableau_new(viewer), image->width(), image->height(), create_menus());
} 

