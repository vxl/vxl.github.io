// gtk-movie-player.cxx
//

#include <vbl/vbl_sprintf.h> 
#include <vgui/vgui_deck.h> 
#include <vgui/vgui.h> 

#include <vgui/vgui_image_tableau.h> 
#include <vgui/vgui_viewer2D.h> 
#include <vgui/vgui_shell_tableau.h>
#include <vcl/vcl_cstdlib.h> 
#include <vgui/impl/gtk/vgui_gtk_adaptor.h> 
#include <gtk/gtk.h> 
#include <gtkgl/gtkglarea.h>

int idlecallbackid= -1; 
int timer= 30;

gint idlecallback( gpointer context)
{ 
  ((vgui_deck*)context)->next(); 
  ((vgui_deck*)context)->post_redraw(); 
  return TRUE;
} 

gint playimage(GtkWidget*, gpointer deckptr)
{ 
  idlecallbackid = gtk_timeout_add(timer, idlecallback, deckptr); 
  return TRUE;
}

gint stopimage(GtkWidget*, gpointer deckptr)
{ 
  gtk_timeout_remove(idlecallbackid); 
  idlecallbackid= -1; 
  return TRUE;
} 

int main(int argc, char ** argv)
{ 
  vgui::select("gtk");
  vgui::init(argc, argv);

  vgui_deck_new deck;

  // Load the images into image tableaux and add them to the deck:
  for (int i=1; i<10; ++i)
  { 
    vbl_sprintf name("/users/pcp/bt/mit/bt.%03d.mit", i);
    vgui_image_tableau_new image(name); 
    deck->add(image); 
  }

  // then a zoomer : 
  vgui_viewer2D_new zr(deck); 

  // plug into a GL context : 
  vgui_gtk_adaptor *ct = new vgui_gtk_adaptor;
  //vgui_gtk_adaptor *ct = vgui_gtk_adaptor();
  GtkWidget *glarea= ct->get_glarea_widget(); 
  gtk_widget_set_usize(GTK_WIDGET(glarea), 400, 400);

  // and set up the context
  ct->set_tableau(vgui_shell_tableau_new(zr));

  GtkWidget *window= gtk_window_new (GTK_WINDOW_TOPLEVEL); 
  GtkWidget *buttonbox= gtk_hbox_new (FALSE, 0); 
  GtkWidget *holderbox= gtk_vbox_new (FALSE, 0); 
  GtkWidget *playbutton= gtk_button_new_with_label ("Play"); 
  GtkWidget *stopbutton= gtk_button_new_with_label ("Stop");

  gtk_box_pack_start (GTK_BOX (buttonbox), stopbutton, TRUE, TRUE, 5); 
  gtk_box_pack_start (GTK_BOX (buttonbox), playbutton, TRUE, TRUE, 3); 
  gtk_box_pack_start (GTK_BOX (holderbox), buttonbox, TRUE, TRUE, 4); 
  gtk_box_pack_start (GTK_BOX (holderbox), glarea, TRUE, TRUE, 0);

  gtk_container_add(GTK_CONTAINER(window),GTK_WIDGET(holderbox)); 
  gtk_signal_connect (GTK_OBJECT (playbutton), "clicked", GTK_SIGNAL_FUNC (playimage), &deck); 
  gtk_signal_connect (GTK_OBJECT (stopbutton), "clicked", GTK_SIGNAL_FUNC (stopimage), &deck);

  gtk_widget_show(playbutton); 
  gtk_widget_show(stopbutton); 
  gtk_widget_show(buttonbox); 
  gtk_widget_show(holderbox);  
  gtk_widget_show(glarea); 
  gtk_widget_show(window);

  return vgui::run();
} 
